### HTTP Basic Authorization Plugin

