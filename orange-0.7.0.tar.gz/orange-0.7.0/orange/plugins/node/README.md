### node plugin（容器集群节点管理插件）

- 新增集群节点注册命令 `orange register`
- 通过 dashboard 面板同步节点配置信息
- 配合 persist 插件，可以查看历史统计信息