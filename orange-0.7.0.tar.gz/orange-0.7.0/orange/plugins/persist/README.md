### 存储插件

#### 使用场景

- 定时将cache数据落到日志、Redis、MySQL
- 手动触发cache数据落地
