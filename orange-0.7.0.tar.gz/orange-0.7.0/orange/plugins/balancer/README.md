此插件依赖以下两个库，可用luarocks安装

- luarocks install penlight
- luarocks install lua-resty-dns-client

安装和使用文档可参考[Orange Balancer 安装及使用](http://zhjwpku.com/2017/11/14/orange-balancer-plugin-tutorial.html)